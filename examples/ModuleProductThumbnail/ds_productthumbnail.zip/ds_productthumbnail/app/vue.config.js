module.exports = {
  publicPath: '',
  css: {
    // extract CSS in components into a single CSS file (only in production)
    // can also be an object of options to pass to extract-text-webpack-plugin
    extract: false,
    // Enable CSS modules for all css / pre-processor files.
    // This option does not affect *.vue files.
    modules: true,
    // enable CSS source maps?
    sourceMap: false,

    loaderOptions: {
        sass:{
            css: 'css-loader',
            'scss':'css-loader | sass-loader'
        }
    }
},
  configureWebpack: {
    output: {
      jsonpFunction: 'jsonpFunction',
      filename: '[name].js',
      chunkFilename: '[name].js'
    }
  },
  chainWebpack: config => {
    const svgRule = config.module.rule('svg')
    svgRule.uses.clear()
    svgRule
      .use('url-loader')
        .loader('url-loader')
        .end()
      .use('svgo-loader')
        .loader('svgo-loader')
        .options({ plugins: [ { removeViewBox: false } ] })
        .end()
  }
}
