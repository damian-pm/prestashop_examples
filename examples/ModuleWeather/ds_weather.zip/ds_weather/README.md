# prestashop-module-template
PrestaShop Module Template with Vue CLI

### Install
Go to prestashop dir /modules, next clone this repo there ... ready to work.
