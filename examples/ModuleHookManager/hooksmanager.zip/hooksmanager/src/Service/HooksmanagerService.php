<?php

namespace PrestaShopBundle\Service;

class HooksmanagerService {
    
}